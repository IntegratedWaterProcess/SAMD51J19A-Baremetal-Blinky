/*
 * Code generated from Atmel Start.
 *
 * This file will be overwritten when reconfiguring your Atmel Start project.
 * Please copy examples or other code you want to keep to a separate file
 * to avoid losing it when reconfiguring.
 */

#include "driver_init.h"
#include <peripheral_clk_config.h>
#include <utils.h>
#include <hal_init.h>

void delay_driver_init(void)
{
	delay_init(SysTick);
}


void BUILTIN_LED_init(void)
{
	gpio_set_pin_direction(LED_BUILTIN, GPIO_DIRECTION_OUT);		// SET PIN DIRECTION AS AN OUTPUT
	gpio_set_pin_function(LED_BUILTIN, GPIO_PIN_FUNCTION_OFF);
	gpio_set_pin_level(LED_BUILTIN,false);
}


void system_init(void)
{
	init_mcu();

	delay_driver_init();
	
	BUILTIN_LED_init();
	
	
}
